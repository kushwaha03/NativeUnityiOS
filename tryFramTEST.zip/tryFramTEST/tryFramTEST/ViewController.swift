//
//  ViewController.swift
//  tryFramTEST
//
//  Created by Sandeep M on 31/12/19.
//  Copyright © 2019 Kiksar. All rights reserved.
//

import UIKit
import UnityFramework
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        UnityEmbeddedSwift.showUnity()
        self.navigationController?.pushViewController(UnityEmbeddedSwift.getUnityRootC(), animated: true)


    }


}

