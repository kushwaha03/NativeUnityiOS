//
//  ViewController.swift
//  iOS2U
//
//  Created by Sandeep M on 10/01/20.
//  Copyright © 2020 Kiksar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var showuBtn = UIButton()
    var sndmsgBtn = UIButton()
    var iscallCon = false
    

      var skuIdFromCW = "E17A7653"
     var userIdFromCW = "sbharti"
      var authKeyFromCW = "AFKSOCMQJ2SP2BKI3WUPJ547NWUL5YFF4AKBA3AUDC4MDIXM6LTLVAREEGTFCQZNLHQQ===="
      var favArray = "E25B6612,E25C6625,E33A6651"
    var analyticsKey = "test"
    
    
    @IBOutlet weak var msgLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        msgLbl.isHidden = true
        // Do any additional setup after loading the view.
        NotificationCenter.default.addObserver(self, selector: #selector(self.methodOfReceivedNotification(notification:)), name: Notification.Name("NotificationIdentifier"), object: nil)
         UserDefaults.standard.removeObject(forKey: "PasMSG")
        if iscallCon {
            msgLbl.isHidden = false

            if let a =  UserDefaults.standard.string(forKey: "PasMSG") {
            msgLbl.text = a
            }
        }
 

    }
    override func viewWillAppear(_ animated: Bool) {

        if let a =  UserDefaults.standard.string(forKey: "PasMSG") {
            msgLbl.isHidden = false

                  msgLbl.text = a
                  }
    }
//    override func viewDidAppear(_ animated: Bool) {
//        msgLbl.isHidden = true
//
//    }
    
    @objc func methodOfReceivedNotification(notification: Notification) {
        let vc  = self.storyboard!.instantiateViewController(withIdentifier: "ViewController") as! ViewController
//        UnityEmbeddedSwift.unloadUnity()
//        vc.nametera = "kya hai re"
//                          self.navigationController?.pushViewController(vc, animated: true)
//        iscallCon = true
                _ = navigationController?.popViewController(animated: true)
    }
        @objc func btnClickedForSendMSG() {
            print("Button Clicked")
    //        UnityEmbeddedSwift.showHostMainWindow("")
            let a = " abc "
            let b = " xyz "

            let c = " pqr "

            let msgis = "hello kiksar" + a + b + c + "how is doing?"
            
               UnityEmbeddedSwift.sendUnityMessage("CommunicateCS1", methodName: "sendMsg", message: msgis)
//            UnityEmbeddedSwift.sendUnityMessage("Cube", methodName: "ChangeColor", message: "red")

        }
    
     func SendMSG() {
     
                let a = " abc "
                let b = " xyz "

                let c = " pqr "

                let msgis = "hello kiksar" + a + b + c + "how is doing?" + " lets be start!"
                
//                   UnityEmbeddedSwift.sendUnityMessage("NativeCommunication", methodName: "sendMsg", message: msgis)
        let msg = skuIdFromCW + "*" + userIdFromCW + "*" + authKeyFromCW + "*" + favArray + "*" + analyticsKey;
//           KiXrUnity.showUnity()
           UnityEmbeddedSwift.sendUnityMessage("NativeCommunication", methodName: "MessageFromiOS", message: msg)

            }
    @IBAction func showUnity(_ sender: Any) {
        UnityEmbeddedSwift.showUnity()
        self.navigationController?.pushViewController(UnityEmbeddedSwift.getUnityRootC(), animated: true)
        SendMSG()
        addBtn()


    }
    
    @IBAction func sendBtn(_ sender: Any) {
        UnityEmbeddedSwift.showUnity()
        self.navigationController?.pushViewController(UnityEmbeddedSwift.getUnityRootC(), animated: true)

        UnityEmbeddedSwift.sendUnityMessage("CommunicateCS1", methodName: "sendMsg", message: "red is red ")
    }
    func addBtn() {
        showuBtn = UIButton(frame: CGRect(x: 200, y: 250, width: 200, height: 40))
        sndmsgBtn = UIButton(frame: CGRect(x: view.frame.width/2-150, y: view.frame.height/2, width: 150, height: 40))

        showuBtn.setTitle("From IOS", for: .normal)
        sndmsgBtn.setTitle("Send MSG", for: .normal)

        showuBtn.backgroundColor = .black
        sndmsgBtn.backgroundColor = .white
        sndmsgBtn.setTitleColor(.black, for: .normal)
        
        showuBtn.addTarget(self, action:#selector(self.btnClickedForSendMSG), for: .touchUpInside)
        sndmsgBtn.addTarget(self, action:#selector(self.btnClickedForSendMSG), for: .touchUpInside)

//        UnityEmbeddedSwift.getUnityV()?.addSubview(showuBtn)
//        UnityEmbeddedSwift.getUnityV()?.addSubview(sndmsgBtn)


    }
    func passedC() {
        let vc  = self.storyboard!.instantiateViewController(withIdentifier: "DetailsVC") as! DetailsVC
                   self.navigationController?.pushViewController(vc, animated: true)
    }
}

